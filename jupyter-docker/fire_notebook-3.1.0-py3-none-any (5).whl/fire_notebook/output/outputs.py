'''
    Copyright 2017 Sparkflows Inc.
'''
from typing import List

from fire_notebook.output.output import Output


class Outputs:
    def __init__(self, outputs: List[Output] = []):
        self.outputs = outputs
