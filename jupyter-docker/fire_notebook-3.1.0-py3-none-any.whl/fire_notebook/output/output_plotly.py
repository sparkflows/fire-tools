'''
    Copyright 2017 Sparkflows Inc.
'''
from fire_notebook.output.output import Output


class OutputPlotly(Output):
    def __init__(self, id: int, name: str, title: str, text: str, resultType: int, visibility: str):
        self.text = text

        super().__init__(id, name, title, type="plotly", resultType=resultType, visibility=visibility)

    def dump(self):
        d = {k: v for k, v in vars(self).items()}
        return d

    @staticmethod
    def load(d: dict):
        return OutputPlotly(**d)

    def toJSON1(self):
        tempStr = str(self.dump())


        return tempStr



