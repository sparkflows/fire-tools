'''
    Copyright 2020 Sparkflows Inc.
'''
from fire_notebook.output.output_header import OutputHeader
from fire_notebook.output.output_text import OutputText
from fire_notebook.output.output_table import OutputTable
from fire_notebook.output.output_success import OutputSuccess
from fire_notebook.output.output_failure import OutputFailure
from fire_notebook.output.output_model import OutputModel
from fire_notebook.output.output_graph import OutputGraph
from fire_notebook.output.output_html import OutputHTML
from fire_notebook.output.output_plotly import OutputPlotly
from fire_notebook.output.output_running import OutputRunning
from fire_notebook.output.output_parameters import OutputParameters
from fire_notebook.output.output_progress import OutputProgress
from fire_notebook.output.output_textinput import OutputTextInput

import requests
import numpy as np
import pandas as pd
import re
import json

class RestWorkflowContext():
    def __init__(self, webserverURL: str = None, jobId: str = None, debug=True, parameters:list=None):

        self.curNodeId = 9999
        self.debug: bool = debug

        self.parameters_dict = {}  # dict of key and value
        if parameters is not None:
            self.webserverURL = parameters[1]
            self.jobId = parameters[2]

            # Parmeters will be passed from Analytical app as comma separated `key=value` pair

            if len(parameters) > 3:
                parameters_custom = parameters[3]
                parameters_list = parameters_custom.split(",")

                # Dictionary of key and value.
                for i in range(len(parameters_list)):
                    key_value = str(parameters_list[i]).split("=")
                    key = key_value[0]
                    value = key_value[1]
                    self.parameters_dict[key] = value
        else:

            if webserverURL is not None:
                self.webserverURL: str = webserverURL

            if jobId is not None:
                self.jobId: str = jobId

        if debug:

            print("WebserverURL:"+self.webserverURL)
            print("jobId:"+self.jobId)

    def sendMessage(self, message: str):

        print("webserverURL: ")
        print(self.webserverURL)

        if self.webserverURL is None :
            return

        if (self.debug):
            print("Sending Message: " + message)

        if not str(self.webserverURL).lower().startswith("http"):
            print("Not sending message to fire_notebook server as the post back URL is not http")
            return ""

        data = { "jobId" : self.jobId , "message"  : message }

        # send POST to webserverURL with parameters
        try:
            result = requests.post(url=self.webserverURL, json=data, verify=False)
        except Exception as e:
            errstr = "Error : " + str(e)
            print(errstr)
            result = errstr

        return result

    def outStr(self, id:int, title: str, text: str):
        text = text.replace('\n', '<br>')

        outputText = OutputText(id, name= title, title=title, text=text, resultType=3,
                                visibility="EXPANDED")
        self.outText(outputText)

    def outNameValue(self, nm: str, val: str):
        outputText = OutputText(self.curNodeId, nm, "title", val, resultType=3,
                                visibility="EXPANDED")
        self.outText(outputText)

    def outText(self, text: OutputText):
        str = text.toJSON1()
        self.sendMessage(str)

    def outHeader(self, header: OutputHeader):
        tstr = header.toJSON1()
        self.sendMessage(tstr)

    def outHeaderValues(self, id: int, name: str, tstr: str):
        outputHeader: OutputHeader = OutputHeader(id, name, name, tstr, resultType=3, visibility="EXPANDED")
        self.outHeader(outputHeader)

    def outSuccess(self, id: int, title: str, text: str):

        success = OutputSuccess(id=id, name=title, title=title, text= text,  resultType=3, visibility="EXPANDED")
        str = success.toJSON1()
        self.sendMessage(str)

    def outFailure(self, id: int, title: str, text: str):

        failure = OutputFailure(id=id, name=title, title=title, text= text,  resultType=3, visibility="EXPANDED")
        str = failure.toJSON1()
        self.sendMessage(str)

    def outRunning(self, id: int, title: str, text: str):

        failure = OutputRunning(id=id, name=title, title=title, text= text,  resultType=3, visibility="EXPANDED")
        str = failure.toJSON1()
        self.sendMessage(str)

    def outFailureValues(self, id: int, name: str, tstr: str):
        outputFailure: OutputFailure = OutputFailure(id, name, name, tstr, resultType=3, visibility="EXPANDED")
        self.outFailure(outputFailure)

    def outTable(self, table: OutputTable):
        str = table.toJSON1()
        self.sendMessage(str)

    def outModel(self, model: OutputModel):
        str = model.toJSON1()
        self.sendMessage(str)

    def outSchema(self, id: int, title: str, df: pd.DataFrame):

        if df == None:
            return

        d = [[]]

        r1 = [f.name for f in df.schema.fields]  #column name
        column_types = [f.dataType for f in df.schema.fields] #column type
        r2 = list(map(lambda col_type: str(col_type), column_types))

        d[0] = r1
        d.append(r2)

        outputTable = OutputTable(id=id, name="Schema", title=title, cellValues=d, resultType=3, visibility="COLLAPSED")

        self.outTable(outputTable)


    def outDataFrame(self, id: int, title: str, df: pd.DataFrame, num_rows: int = 10):

        if df is None:
            return

        outputTable = OutputTable.dataFrameToOutputTable(id, title, df, num_rows)

        self.outTable(outputTable)

    def outPandasDataframe(self, id: int, title: str, df: pd.DataFrame, num_rows: int = 10):
        outputTable = OutputTable.pandasDataFrametoOutputTable(id, title, df, num_rows)

        self.outTable(outputTable)

    def outNumpy1darray(self, id: int, title: str, arr: np.ndarray):
        sss = arr.tostring()
        sss = ""
        c = arr.shape[0]
        for k in range(c):
            sss += str(arr[k]) + " "
        self.outNameValue(title, sss)

    def outNumpy2darray(self, id: int, title: str, arr: np.ndarray):
        outputTable = OutputTable.convertNumpyndarraytoOutputTable(id, title, arr)

        self.outTable(outputTable)

    def outPandasDataframeChart(self, title: str,  x_column: str, y_columns: list(), chart_type: str, df: pd.DataFrame, numRowsToDisplay: int):

        outputGraph = OutputGraph.pandasdataFrameToChart(title=title, x_column=x_column, y_columns=y_columns, graph_type=chart_type,
                                           df=df, numRowsToDisplay=numRowsToDisplay)
        str = outputGraph.toJSON1()
        self.sendMessage(str)

    def outDataframeChart(self, title: str, x_column: str, y_columns: list(), chart_type: str,
                                df: pd.DataFrame, numRowsToDisplay: int):

        outputGraph = OutputGraph.dataFrameToChart(title=title, x_column=x_column, y_columns=y_columns,
                                                         graph_type=chart_type,
                                                         df=df, numRowsToDisplay=numRowsToDisplay)
        str = outputGraph.toJSON1()
        self.sendMessage(str)

    def outHTML(self, id: int, title: str, text: str):

        print("Check the Input type.")

        res = isinstance(text, str)

        if res == False:

            if text is None:
                print("Input type is None")

            if text is not None:
                print("Input is not string type. Pls check the input")

            return
        import unicodedata

        new_text = text.replace("\"\"", "\"").replace("\"", "@@").replace("<br>", "")
        final_text = unicodedata.normalize("NFKD", new_text)

        print(" And Input is string type.")
        outputHTML = OutputHTML(id, name=title, title=title,
                                text=final_text,
                                resultType=3,
                                visibility="EXPANDED")

        out_str = outputHTML.toJSON1()
        print("++++++")
        self.sendMessage(out_str)
        print("++++++")

    def outPlotly(self, id: int, title: str, text: str):

        print("Check the Input type..")

        res = isinstance(text, str)

        if res == False:

            if text is None:
                print("Input type is None")

            if text is not None:
                print("Input is not string type. Pls check the input")

            return


        m = re.search('.*Plotly.newPlot(.+?)};                            </script>        </div>', text)
        if m:
            print("There is a match")
            new_text = m.group(1).replace("\"", "@@").strip()

        print(" And Input is string type.")
        outputPlotly = OutputPlotly(id, name=title, title=title, text="Plotly.newPlot"+new_text, resultType=3,
                                    visibility="EXPANDED")
        out_str = outputPlotly.toJSON1()
        self.sendMessage(out_str)

    def outDictionaryToTable(self, id:int, title:str, parameters: dict):

        if parameters is None or len(parameters) == 0:
            raise Exception("Parameters is ")


        outputTable = OutputTable.convertDictToOutputTable(id=id, title=title, parameters=parameters)

        self.outTable(outputTable)

    def outParameters(self, id: int, title: str, parameters: []):

        outputParameters = OutputParameters(id=id, name=title, title=title, parameters=parameters, resultType=3, visibility="EXPANDED")

        out_paramerts = outputParameters.toJSON1()
        self.sendMessage(out_paramerts)

    def outputProgress(self, id:int, title: str, progress: str):

        outputProgress = OutputProgress(id, name= title, title=title, progress=progress, resultType=3,
                                visibility="EXPANDED")
        self.sendMessage(outputProgress.toJSON1())

    def getTextInput(self, id:int, title: str, url: str):

        import uuid
        import time

        uuid_value = str(uuid.uuid1())
        outputTextInput = OutputTextInput(id, name=title, title=title, uuid=uuid_value, resultType=3,
                                        visibility="EXPANDED")

        self.sendMessage(outputTextInput.toJSON1())
        time.sleep(15)

        if(url.endswith("/")):
         api_end_point = str(url)+"api/v1/webApps/polls/"+uuid_value+"/userInputs"
        else:
            api_end_point = str(url) + "/api/v1/webApps/polls/" + uuid_value + "/userInputs"

        status = False
        print("Polling API endpoint:" + api_end_point)

        start_time = time.time()
        message = "User Response Time Out!."
        return_message = message
        total_time = 0 #inseconds

        while(not status and total_time < 120):
            response = requests.get(
                api_end_point, verify=False
            )

            total_time = time.time() - start_time
            print("Status code of the response: " + str(response.status_code))
            if str(response.status_code) == "200":
                status = True
                message = str(response.json()[title])
                return_message = "Successfully recevied the value."
                print("Successfully recevied the message.")
            time.sleep(10)

        self.outStr(id, "Response Status", return_message)
        return message


    def getParmeters(self, parameter_name: str, default=None):

        return self.parameters_dict.get(parameter_name, default)


    def getConnectionDetails(self, conn_name: str, default=None):



        try:
            url = "api/v1/connections/jobs/" + self.jobId + "/" + conn_name

            print(url)

            api_end_point = self.webserverURL.replace("messageFromSparkJob", url)

            print("api_end_point:" + api_end_point)
            response = requests.get(url=api_end_point, verify=False)

            print("Status code of the response: " + str(response.status_code))

        except Exception as e:
            errstr = "Error : " + str(e)
            print(errstr)
            result = errstr


        if str(response.status_code) == "200":
            json_data = str(response.json())
            print("Data received:", json_data)
            return json_data
        else:

            return default
