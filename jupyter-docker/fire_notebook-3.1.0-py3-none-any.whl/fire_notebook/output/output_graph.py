'''
    Copyright 2017 Sparkflows Inc.
'''
from fire_notebook.output.output import Output
from fire_notebook.output.output_table import OutputTable
import pyspark.sql.dataframe as DataFrame
import pandas as pd

class OutputGraph(Output):
    def __init__(self, id: int, name: str, title: str, xlabel: str, x: [],
                 ylabel: str, y: [[]],
                 graphType: [],
                 colors: [],
                 isStreaming: bool,
                 resultType: int, visibility: str):

        self.y = y
        self.x = x
        self.xlabel = xlabel
        self.ylabels = ylabel
        self.graphTypes = graphType
        self.isStreaming = isStreaming

        super().__init__(id, name, title, "graph", resultType, visibility)

    def dump(self):
        d = {k: v for k, v in vars(self).items()}
        return d

    def __str__(self):
        return str(self.id) + " : " + self.name + " : " + self.title

    @staticmethod
    def load(d: dict):
        return OutputTable(**d)

    def toJSON(self):
        tempStr = str(self.dump())

        # replace ' with \"
        tempStr = tempStr.replace("\'", "\\\"")

        return tempStr

    def toJSON1(self):
        tempStr = str(self.dump())

        # replace ' with \"
        tempStr = tempStr.replace("\'", "\"")

        return tempStr

    #Different graph types: COLUMNCHART, BARCHART, LINECHART, HISTOGRAM, SCATTERCHART,

    @staticmethod
    def dataFrameToChart(title: str,  x_column: str, y_columns: list(), graph_type: str, df: DataFrame, numRowsToDisplay: int):

        #new_df = df.select(list(y_columns))
        #get the rows
        #ydf_rows = new_df.take(numRowsToDisplay)


        #find the count of the groups
        #count = len(ydf_rows)

        # create x[] values from the xCol name
        x = []
        #given the xCol get the values of x[]
        xdf = df.select(x_column)
        xdf_rows = xdf.take(numRowsToDisplay)

        if x_column != None and len(x_column) > 0:
            for row in xdf_rows:
                for element in row:
                    x.append(str(element))

        y = []

        for i in range(len(y_columns)):
            colName = y_columns[i]
            new_df = df.select(colName)
            ydf_rows = new_df.take(numRowsToDisplay)

            data_col = []
            for row in ydf_rows:
                for element in row:
                    data_col.append(float(element))

            y.append(data_col)

        graphType = []
        graphType.append(graph_type)

        colors = []
        isStreaming = False


        outputGraph = OutputGraph(id = 9, name="", title=title, xlabel=x_column, x=x,
                                              ylabel= y_columns, y = y, graphType=graphType, colors=colors, isStreaming= isStreaming,
                                  resultType=3, visibility="EXPANDED")

        return outputGraph

    # Converts the given Pandas DataFrame to OutputTable
    @staticmethod
    def pandasdataFrameToChart(title: str, x_column: str, y_columns: list(), graph_type: str, df: pd.DataFrame, numRowsToDisplay: int):

        # create x[] values from the xCol name
        x = []
        # given the xCol get the values of x[]
        xdf = df[[x_column]]
        xdf_lists = xdf.head(numRowsToDisplay).values.tolist()

        for k in range(len(xdf_lists)):
            v = xdf_lists[k][0]
            x.append(v)

        y = []

        for i in range(len(y_columns)):
            colName = y_columns[i]
            new_df = df[colName]
            ydf_lists = new_df.head(numRowsToDisplay).values.tolist()
            y.append(ydf_lists)

        graphType = []
        graphType.append(graph_type)

        colors = []
        isStreaming = False

        outputGraph = OutputGraph(id = 9, name="", title=title, xlabel=x_column, x=x,
                                              ylabel= y_columns, y = y, graphType=graphType, colors=colors, isStreaming= isStreaming,
                                  resultType=3, visibility="EXPANDED")

        return outputGraph

if __name__ == '__main__':
    print("Testing OutputGraph")

    d = {'col1': [1, 2], 'col2': [3, 4]}
    df = pd.DataFrame(data=d)

    outputGraph = OutputGraph.pandasdataFrameToChart(title="TEST", x_column="col1", y_columns=["col2"],
                                                     graph_type="LINECHART", df=df, numRowsToDisplay=10)
    print(outputGraph.toJSON())



    print("DONE")