'''
    Copyright 2017 Sparkflows Inc.
'''
from fire_notebook.output.output import Output


class OutputTextInput(Output):
    def __init__(self, id: int, name: str, title: str, uuid: str, resultType: int, visibility: str):
        self.uuid = uuid
        super().__init__(id, name, title, "textinput", resultType, visibility)

    def dump(self):
        d = {k: v for k, v in vars(self).items()}
        return d

    @staticmethod
    def load(d: dict):
        return OutputTextInput(**d)

    def toJSON1(self):
        tempStr = str(self.dump())

        # replace ' with \"
        tempStr = tempStr.replace("\'", "\"")

        return tempStr
