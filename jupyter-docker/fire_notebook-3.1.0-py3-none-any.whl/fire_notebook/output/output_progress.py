'''
    Copyright 2017 Sparkflows Inc.
'''
from fire_notebook.output.output import Output


class OutputProgress(Output):
    def __init__(self, id: int, name: str, title: str, progress: str, resultType: int, visibility: str):
        self.progress = progress

        super().__init__(id, name, title, "progress", resultType, visibility)

    def dump(self):
        d = {k: v for k, v in vars(self).items()}
        return d

    @staticmethod
    def load(d: dict):
        return OutputProgress(**d)

    def toJSON1(self):
        tempStr = str(self.dump())

        # replace ' with \"
        tempStr = tempStr.replace("\'", "\"")

        return tempStr