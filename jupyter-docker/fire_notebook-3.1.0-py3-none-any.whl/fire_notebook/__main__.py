'''
    Copyright 2020 Sparkflows Inc.
'''
import os
import signal
import platform

import pandas as pd

from fire_notebook.output.output_text import OutputText
from fire_notebook.output.workflowcontext import RestWorkflowContext

"""Starts the HTTPServer to start serving the requests."""

def test_console():  # -> None:
    print("output")

    curNodeId = 1
    nm = "aaa"
    val = "Starting Program"
    outputText = OutputText(curNodeId, nm, "title", val, resultType=3,
                            visibility="EXPANDED")

    json = outputText.toJSON1()
    print(json)

def test_text(webserverURL: str, jobId: str):
    print("output")

    curNodeId = 1
    nm = "aaa"
    val = "Starting Program"
    outputText = OutputText(curNodeId, nm, "title", val, resultType=3, visibility="EXPANDED")

    restworkflowcontext = RestWorkflowContext(webserverURL, jobId)
    restworkflowcontext.outText(outputText)

def test_table(webserverURL: str, jobId: str):
    print("output")

    restworkflowcontext = RestWorkflowContext(webserverURL, jobId)

    # list of strings
    lst = ['Geeks', 'For', 'Geeks', 'is',
           'portal', 'for', 'Geeks']

    # Calling DataFrame constructor on list
    df = pd.DataFrame(lst, columns=['name'])

    print(df)

    restworkflowcontext = RestWorkflowContext(webserverURL, jobId)
    restworkflowcontext.outPandasDataframe(9, "Names", df)

if __name__ == '__main__':
    test_console()

    # get the webserverURL and jobId from the parameters passed to the notebook

    webserverURL = "http://localhost"
    jobId = "22456-98674547-985647"

    test_text(webserverURL, jobId)

    test_table("http://localhost", "fdsafds")

