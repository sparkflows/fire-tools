'''
    Copyright 2020 Sparkflows Inc.
'''
import os
import signal
import platform

import pandas as pd

from fire_notebook.output.output_text import OutputText
from fire_notebook.output.workflowcontext import RestWorkflowContext

"""Starts the HTTPServer to start serving the requests."""

def test_console():  # -> None:
    print("output")

    curNodeId = 1
    nm = "aaa"
    val = "Starting Program"
    outputText = OutputText(curNodeId, nm, "title", val, resultType=3,
                            visibility="EXPANDED")

    json = outputText.toJSON1()
    print(json)

def test_text(webserverURL: str, jobId: str):
    print("output")

    curNodeId = 1
    nm = "aaa"
    val = "Starting Program"
    outputText = OutputText(curNodeId, nm, "title", val, resultType=3, visibility="EXPANDED")

    restworkflowcontext = RestWorkflowContext(webserverURL, jobId)
    restworkflowcontext.outText(outputText)

def test_table(webserverURL: str, jobId: str):
    print("output")

    restworkflowcontext = RestWorkflowContext(webserverURL, jobId)

    # list of strings
    lst = ['Geeks', 'For', 'Geeks', 'is',
           'portal', 'for', 'Geeks']

    # Calling DataFrame constructor on list
    df = pd.DataFrame(lst, columns=['name'])

    print(df)

    restworkflowcontext = RestWorkflowContext(webserverURL, jobId)
    restworkflowcontext.outPandasDataframe(9, "Names", df)

if __name__ == '__main__':

    # get the webserverURL and jobId from the parameters passed to the notebook

    webserverURL = "http://localhost"
    jobId = "22456-98674547-985647"

    #test_text(webserverURL, jobId)

    #test_table("http://localhost", "fdsafds")

    trim = ["","http://a3d8b407eb41c418797a8c5a5dd7a04c-1747681388.us-east-1.elb.amazonaws.com:8080/messageFromSparkJob", "dd73a0f3-daf2-4d2d-acab-42a57f04d6cd"]

    print(trim)
    '''
    import sys
    parameter_list = trim
    restWorkflowContext = RestWorkflowContext(parameters=parameter_list, debug=False)

    connection_details = restWorkflowContext.getConnectionDetails(conn_name="mysql", default="host,port,username,password")
    print(connection_details)
    import json
    # Parse the JSON data

    if connection_details is not None and connection_details != "host,port,username,password":

        # Access data from the parsed JSON
        print("Connection Name:", connection_details['connectionName'])
        print("URL:", connection_details['url'])
        print("Username:", connection_details['username'])
        print("Password:", connection_details['password'])
        print("DriverClass:", connection_details['driverClass'])
        
        
    '''
    from fire_notebook.output.workflowcontext import RestWorkflowContext
    import sys

    parameters_list = sys.argv
    parameters_list = trim

    if len(parameters_list) > 1:
        restworkflowcontext = RestWorkflowContext(parameters=parameters_list, debug=True)
    else:
        print("==++==++==")
        restworkflowcontext = RestWorkflowContext(debug=False)

    user_details = restworkflowcontext.getUserDetailsOfAppExecute()
    print("++===+++==+++==")
    print(user_details)

    message = "Successfully Received the Message from Notebook!"
    restworkflowcontext.outStr(9, title="Message", text=message)

    # To get the parameters value
    parameter_value = restworkflowcontext.getParmeters(parameter_name="key", default="Value")
    print("parameter_value for key is: ")
    print(parameter_value)

    # To get the connection details
    connection_details = restworkflowcontext.getConnectionDetails(conn_name="mysql",
                                                                  default="host,port,database,username,password")
    print(connection_details)

    if connection_details is not None and str(connection_details) != "host,port,database,username,password":
        # Access data from the parsed JSON
        print("Connection Name:", connection_details['connectionName'])
        print("URL:", connection_details['url'])
        print("Username:", connection_details['username'])
        print("Password:", connection_details['password'])
        print("DriverClass:", connection_details['driverClass'])

    # Output as Text
    restworkflowcontext.outStr(id=9, title="Test String", text="text")

    # Output HTML
    htmlstr1 = "<h3>You can view HTML code in notebooks.</h3>"

    restworkflowcontext.outHTML(id=9, title="Example HTML", text=htmlstr1)

    # list of strings
    lst = ['Geeks', 'For', 'Geeks', 'is',
           'portal', 'for', 'Geeks']

    # Calling DataFrame constructor on list
    import pandas as pd

    df = pd.DataFrame(lst, columns=['name'])
    print(df)

    restworkflowcontext.outPandasDataframe(id=9, title="Names", df=df, num_rows=10)

    # Output Messages: To indicate the execution status of the job
    message = "Sending the success message."
    restworkflowcontext.outSuccess(id=9, title="Success", text=message)

    message = "Sending the failure message."
    restworkflowcontext.outFailure(id=9, title="Failure", text=message)

    message = "Sending the running message."
    restworkflowcontext.outRunning(id=9, title="Running", text=message)

    # Output Progress Message: To share the progress of the Notebook run as a percentage with the analytical app
    message = "50"
    restworkflowcontext.outputProgress(id=9, title="Progress", progress=message)

    # Get Input Value: Analytical apps also allow us to pass a variable value as an input parameter to the notebook execution. If a user doesn’t enter a value within 120 seconds, it will return a default response.
    title = "Name of the Country:"
    country_name = restworkflowcontext.getTextInput(id=9, title=title)
