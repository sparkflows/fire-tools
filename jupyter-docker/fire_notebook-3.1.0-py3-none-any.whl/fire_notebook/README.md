Install virtualenv
- sudo pip install virtualenv


Create python environment via virtualenv
- virtualenv -p python3.6 env
- source env/bin/activate
- pip install -r fire/firepyspark/fire/requirements.txt


Install conda with python 3.6
 - conda activate pydl  # pydl is the environment name created in conda
 - pip3 install -r requirements.txt
